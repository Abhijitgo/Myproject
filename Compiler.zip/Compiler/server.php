<?php

$conn = mysqli_connect("localhost","root","","sessionpracticle") or die("Connection Not Established") ;

?>